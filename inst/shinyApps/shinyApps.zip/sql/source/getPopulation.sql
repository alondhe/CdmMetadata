select count_value
from @resultsDatabaseSchema.achilles_results where analysis_id = 1;